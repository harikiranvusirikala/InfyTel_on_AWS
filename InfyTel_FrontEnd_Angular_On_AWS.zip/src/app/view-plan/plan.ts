export class PlanDetail {
    planId: number;
    planName: string;
    nationalRate: number;
    localRate: number;
}
