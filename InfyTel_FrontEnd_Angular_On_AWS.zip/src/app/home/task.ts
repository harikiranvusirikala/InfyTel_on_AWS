export class Task {
  icon?: string;
  name?: string;
  route?: string;
  description?: string;
}
