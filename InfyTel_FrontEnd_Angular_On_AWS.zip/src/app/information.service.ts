import { Injectable } from "@angular/core";

@Injectable()
export class InformationService {
  // baseURL = "http://localhost:8000";

  phoneNo: number;

  customerBaseUrl = "http://13.127.100.151:8200";
  loginUrl = "http://13.127.100.151:8200/login";
  registerUrl = "http://13.127.100.151:8200/customers/";
  profileUrl = "http://13.127.100.151:8200/customers/";
  viewPlanUrl = "http://65.0.86.250:8400/plans/";
  callDetailUrl = `http://65.0.86.250:8100/customers/`;
  addFriendUrl = `http://13.127.100.151:8300/customers/`;

}
