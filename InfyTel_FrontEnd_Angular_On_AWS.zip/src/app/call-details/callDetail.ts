export class CallDetail {
    calledBy: number;
    calledTo: number;
    calledOn: string;
    duration: number;
}
